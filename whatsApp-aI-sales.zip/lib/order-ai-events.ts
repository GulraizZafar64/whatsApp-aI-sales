import type {
  ParsedAiOrderJson,
  ParsedAiOrderJsonItem,
  ParsedWhatsAppOrderFooter,
} from "@/lib/claude-generate";
import {
  extractDeliveryAddressFromAssistantText,
  looksLikeDeliveryAddress,
} from "@/lib/whatsapp-catalog-match";

export type WhatsAppConversationStage =
  | "default"
  | "order_just_confirmed"
  | "delivery_address_received"
  | "post_purchase_close";

export type OrderAiEventType = "order_create" | "order_update" | "order_cancel";

export type ParsedOrderAiEvent = {
  event: OrderAiEventType;
  items: ParsedAiOrderJsonItem[];
  address?: string;
};

const ORDER_EVENT_MARKER = "[[ORDER_EVENT:";
const VALID_EVENTS = new Set<OrderAiEventType>([
  "order_create",
  "order_update",
  "order_cancel",
]);
const MAX_ORDER_JSON_ITEMS = 20;
const MAX_ORDER_QTY = 10_000;

/** Extract `{…}` JSON after [[ORDER_EVENT: (balanced braces). */
export function extractOrderEventPayloadFromText(text: string): string | null {
  let searchFrom = 0;
  let best: string | null = null;

  while (searchFrom < text.length) {
    const idx = text.indexOf(ORDER_EVENT_MARKER, searchFrom);
    if (idx < 0) break;
    let i = idx + ORDER_EVENT_MARKER.length;
    while (i < text.length && /\s/.test(text[i]!)) i++;
    if (text[i] !== "{") {
      searchFrom = idx + ORDER_EVENT_MARKER.length;
      continue;
    }
    let depth = 0;
    const start = i;
    for (; i < text.length; i++) {
      const ch = text[i]!;
      if (ch === "{") depth++;
      else if (ch === "}") {
        depth--;
        if (depth === 0) {
          best = text.slice(start, i + 1);
          break;
        }
      }
    }
    searchFrom = idx + ORDER_EVENT_MARKER.length;
  }

  return best;
}

function parseItemsFromEventObject(
  v: Record<string, unknown>
): ParsedAiOrderJsonItem[] {
  if (!Array.isArray(v.items)) return [];
  const items: ParsedAiOrderJsonItem[] = [];
  for (const row of v.items) {
    if (!row || typeof row !== "object") continue;
    const o = row as Record<string, unknown>;
    const productId = Number.parseInt(String(o.productId ?? o.id ?? ""), 10);
    const quantity = Number.parseInt(String(o.qty ?? o.quantity ?? 1), 10);
    const unitPrice = Number.parseFloat(String(o.unitPrice ?? o.price ?? 0));
    const sizeRaw =
      typeof o.size === "string"
        ? o.size
        : typeof o.variant === "string"
          ? o.variant
          : "";
    const size = sizeRaw.trim().slice(0, 80) || undefined;
    if (
      Number.isFinite(productId) &&
      productId > 0 &&
      Number.isFinite(quantity) &&
      quantity > 0 &&
      quantity <= MAX_ORDER_QTY
    ) {
      items.push({
        productId,
        quantity,
        unitPrice:
          Number.isFinite(unitPrice) && unitPrice >= 0 ? unitPrice : 0,
        size,
      });
    }
  }
  return items;
}

export function parseOrderAiEvent(raw: string): ParsedOrderAiEvent | null {
  const trimmed = raw.trim();
  if (!trimmed.startsWith("{")) return null;
  try {
    const v = JSON.parse(trimmed) as Record<string, unknown>;
    const eventRaw = String(v.event ?? "").trim().toLowerCase();
    if (!VALID_EVENTS.has(eventRaw as OrderAiEventType)) return null;

    const address =
      typeof v.address === "string"
        ? v.address.trim().slice(0, 2000)
        : undefined;

    return {
      event: eventRaw as OrderAiEventType,
      items: parseItemsFromEventObject(v),
      address: address || undefined,
    };
  } catch {
    return null;
  }
}

function validateEventItems(
  event: ParsedOrderAiEvent,
  validProductIds?: ReadonlySet<number>
): string[] {
  const errors: string[] = [];
  if (!event.items.length) errors.push("items array is empty");
  if (event.items.length > MAX_ORDER_JSON_ITEMS) {
    errors.push(`too many items (max ${MAX_ORDER_JSON_ITEMS})`);
  }
  for (const [i, item] of event.items.entries()) {
    if (!Number.isFinite(item.productId) || item.productId <= 0) {
      errors.push(`items[${i}].productId invalid`);
    } else if (validProductIds && !validProductIds.has(item.productId)) {
      errors.push(`items[${i}].productId ${item.productId} not in catalog`);
    }
    if (
      !Number.isFinite(item.quantity) ||
      item.quantity < 1 ||
      item.quantity > MAX_ORDER_QTY
    ) {
      errors.push(`items[${i}].qty out of range`);
    }
    if (!Number.isFinite(item.unitPrice) || item.unitPrice < 0) {
      errors.push(`items[${i}].unitPrice invalid`);
    }
  }
  if (
    event.address != null &&
    event.address.length > 0 &&
    event.address.length < 4
  ) {
    errors.push("address too short");
  }
  return errors;
}

export function validateOrderAiEvent(
  event: ParsedOrderAiEvent,
  validProductIds?: ReadonlySet<number>
): { ok: true; data: ParsedOrderAiEvent } | { ok: false; errors: string[] } {
  if (event.event === "order_cancel") {
    return { ok: true, data: event };
  }

  const errors = validateEventItems(event, validProductIds);
  if (event.event === "order_create" || event.event === "order_update") {
    if (!event.address?.trim()) {
      errors.push("address required for order_create/order_update");
    }
  }
  if (errors.length) return { ok: false, errors };

  return { ok: true, data: event };
}

export function orderEventToOrderJson(
  event: ParsedOrderAiEvent
): ParsedAiOrderJson | null {
  if (event.event === "order_cancel") return null;
  if (!event.items.length) return null;
  return {
    items: event.items,
    address: event.address,
  };
}

/** Prefer explicit [[ORDER_EVENT:…]]; fall back to legacy tags. */
export function normalizeOrderEventFromAiReply(params: {
  rawReply: string;
  orderJson: ParsedAiOrderJson | null;
  orderFooters?: ParsedWhatsAppOrderFooter[];
  hasPendingOrder: boolean;
  orderUpdateConfirmed: boolean;
}): ParsedOrderAiEvent | null {
  const payload = extractOrderEventPayloadFromText(params.rawReply);
  if (payload) {
    const parsed = parseOrderAiEvent(payload);
    if (parsed) return parsed;
  }

  if (/\[\[CANCEL_ORDER\]\]/i.test(params.rawReply)) {
    return { event: "order_cancel", items: [] };
  }

  const footerItems = (params.orderFooters ?? [])
    .filter((f) => f.productId > 0 && f.quantity > 0)
    .map((f) => ({
      productId: f.productId,
      quantity: f.quantity,
      unitPrice: f.unitPrice,
    }));

  if (footerItems.length && params.orderJson?.address?.trim()) {
    const event: OrderAiEventType =
      params.hasPendingOrder && params.orderUpdateConfirmed
        ? "order_update"
        : "order_create";
    return {
      event,
      items: footerItems,
      address: params.orderJson.address.trim(),
    };
  }

  if (!params.orderJson?.items.length) return null;

  if (params.hasPendingOrder && params.orderUpdateConfirmed) {
    return {
      event: "order_update",
      items: params.orderJson.items,
      address: params.orderJson.address,
    };
  }

  if (!params.hasPendingOrder) {
    return {
      event: "order_create",
      items: params.orderJson.items,
      address: params.orderJson.address,
    };
  }

  return null;
}

/**
 * Fallback when the model confirms an order in chat but omits [[ORDER_EVENT:…]].
 * Only runs when address + cart are already valid (same gates as checkout).
 */
export function synthesizeOrderCreateEventFromCheckout(params: {
  orderIntents: ParsedAiOrderJsonItem[];
  address: string | null | undefined;
  assistantVisibleText?: string | null;
  stage: WhatsAppConversationStage;
  userText: string;
  assistantAskedForAddress: boolean;
  hasPendingOrder: boolean;
  customerCommittedInThread: boolean;
}): ParsedOrderAiEvent | null {
  if (params.hasPendingOrder) return null;
  if (!params.orderIntents.length) return null;
  if (!params.customerCommittedInThread) return null;

  const addressFromAssistant = params.assistantVisibleText
    ? extractDeliveryAddressFromAssistantText(params.assistantVisibleText)
    : null;

  const address =
    params.address?.trim() ||
    addressFromAssistant ||
    (looksLikeDeliveryAddress(params.userText, {
      assistantAskedForAddress: params.assistantAskedForAddress,
    })
      ? params.userText.trim()
      : "");

  if (!address || address.length < 8) return null;
  if (
    !looksLikeDeliveryAddress(address, {
      assistantAskedForAddress: params.assistantAskedForAddress,
    })
  ) {
    return null;
  }

  const assistantConfirmedOrder =
    Boolean(params.assistantVisibleText?.trim()) &&
    /\b(order\s+confirm|order\s+successfully|successfully\s+place|aap\s+ka\s+order|your order\s+(?:is|was)\s+(?:confirm|placed|submit))/i.test(
      params.assistantVisibleText!
    );

  const addressTurn =
    params.stage === "delivery_address_received" ||
    looksLikeDeliveryAddress(params.userText, {
      assistantAskedForAddress: params.assistantAskedForAddress,
    }) ||
    (assistantConfirmedOrder && Boolean(addressFromAssistant));

  if (!addressTurn) return null;

  return {
    event: "order_create",
    items: params.orderIntents,
    address: address.slice(0, 2000),
  };
}

export function stripOrderEventTags(text: string): string {
  let out = text.trim();
  while (true) {
    const idx = out.indexOf(ORDER_EVENT_MARKER);
    if (idx < 0) break;
    const payload = extractOrderEventPayloadFromText(out.slice(idx));
    if (!payload) {
      out = out.slice(0, idx) + out.slice(idx + ORDER_EVENT_MARKER.length);
      continue;
    }
    const payloadStart = out.indexOf(payload, idx);
    if (payloadStart < 0) break;
    let end = payloadStart + payload.length;
    while (end < out.length && /\s/.test(out[end]!)) end++;
    if (out.slice(end, end + 2) === "]]") end += 2;
    out = (out.slice(0, idx) + out.slice(end)).trim();
  }
  return out.replace(/\[\[ORDER_EVENT:[^\]]*\]\]/gi, "").trim();
}

export const ORDER_EVENT_AI_HINT =
  'Database actions use ONE line only: [[ORDER_EVENT:{"event":"order_create"|"order_update"|"order_cancel",...}]]. ' +
  'order_create — customer confirmed + full address: include "items":[{"productId":ID,"qty":1,"unitPrice":PRICE,"size":"Large"}] and "address":"full delivery address". ' +
  'order_update — pending order only, after customer confirmed the change: same JSON shape with final items/address. ' +
  'order_cancel — customer wants to cancel: {"event":"order_cancel"} only. ' +
  "NEVER emit order_create/order_update while still asking size/price or before address. Never emit without customer confirm.";
